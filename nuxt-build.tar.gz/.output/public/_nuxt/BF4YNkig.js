import{j as e}from"./BuMRg0s4.js";const r=t=>e("/about/getAboutContent",{method:"GET",params:{userId:t}}),s=t=>e("/users/editUserInfo",{method:"POST",body:t});export{r as g,s as u};
